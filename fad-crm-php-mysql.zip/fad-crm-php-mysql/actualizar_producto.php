<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php



include_once "funciones2.php";
$ok = actualizarProducto($_POST["nombre"], $_POST["nip"], $_POST["idfabricante"], $_POST["precio"], $_POST["existencias"], $_POST["demora"], $_POST["clase"], $_POST["detalle"], $_POST["comision"], $_POST["id"]);
if (!$ok) {
    echo "Error actualizando.";
} else {
    header("Location: productos.php");
}
