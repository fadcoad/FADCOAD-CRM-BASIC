<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php

include_once "encabezado.php";
include_once "funciones2.php";

// Asumo que el valor de $_GET["id"] ha sido previamente validado

$producto = obtenerProductoPorId2($_GET["id"]);
$clases = obtenerClase();
?>

<div class="row">
    <div class="col-12">
        <h1>Editar producto</h1>
        <form action="actualizar_producto.php" method="post">
            <input type="hidden" name="id" value="<?php echo $producto['id'] ?>">
            <input type="hidden" name="id" value="<?php echo $producto['id'] ?>">

            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input value="<?php echo $producto['nombre'] ?>" required type="text" class="form-control" name="nombre" placeholder="Nombre">
            </div>

            <div class="form-group">
                <label for="nip">NIP</label>
                <input value="<?php echo $producto['nip'] ?>" required type="number" class="form-control" name="nip" placeholder="NIP">
            </div>

            <div class="form-group">
                <label for="idfabricante">ID Fabricante</label>
                <input value="<?php echo $producto['idfabricante'] ?>" required type="number" class="form-control" name="idfabricante" placeholder="ID Fabricante">
            </div>

            <div class="form-group">
                <label for="precio">Precio</label>
                <input value="<?php echo $producto['precio'] ?>" required type="text" class="form-control" name="precio" placeholder="Precio">
            </div>

            <div class="form-group">
                <label for="existencias">Existencias</label>
                <input value="<?php echo $producto['existencias'] ?>" required type="number" class="form-control" name="existencias" placeholder="Existencias">
            </div>

            <div class="form-group">
                <label for="demora">Demora</label>
                <input value="<?php echo $producto['demora'] ?>" required type="text" class="form-control" name="demora" placeholder="Demora">
            </div>

            <div class="form-group">
                <label for="clase">Clase</label>
                <select class="form-control" name="clase">
                    <?php foreach ($clases as $claseOption) { ?>
                        <option <?php echo ($claseOption === $producto['clase']) ? "selected" : ""; ?> value="<?php echo $claseOption ?>"><?php echo $claseOption ?></option>
                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="detalle">Detalle</label>
                <input value="<?php echo $producto['detalle'] ?>" required type="text" class="form-control" name="detalle" placeholder="Detalle">
            </div>

            <div class="form-group">
                <label for="comision">.com</label>
                <input value="<?php echo $producto['comision'] ?>" required type="text" class="form-control" name="comision" placeholder=".com">
            </div>

            <div class="form-group">
                <button class="btn btn-success">Guardar</button>
            </div>
        </form>
    </div>
</div>

<?php include_once "pie.php" ?> ?>