<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "encabezado.php";
include_once "funciones2.php";
$clases = obtenerClase();
?>
<div class="row">
    <div class="col-12">
        <h1>Agregar producto</h1>
        <form action="guardar_producto.php" method="post">

            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input required type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre">
            </div>
            
            <div class="form-group">
                <label for="nip">NIP</label>
                <input required type="number" class="form-control" name="nip" id="nip" placeholder="NIP">
            </div>

            <div class="form-group">
                <label for="idfabricante">ID Fabricante</label>
                <input required type="number" class="form-control" name="idfabricante" id="idfabricante" placeholder="ID Fabricante">
            </div>

            <div class="form-group">
                <label for="precio">Precio</label>
    <input value="<?php echo $producto->precio ?>" required type="text" class="form-control" name="precio" id="precio" placeholder="Precio" pattern="^\d{1,3}(.\d{3})*(\,\d{1,2})?$" title="Ingrese un valor válido para el precio">
            </div>  
            
            <div class="form-group">
                <label for="existencias">Existencias</label>
                <input required type="number" class="form-control" name="existencias" id="existencias" placeholder="Existencias">
            </div>   
            
            <div class="form-group">
                <label for="demora">Demora</label>
                <input required type="text" class="form-control" name="demora" id="demora" placeholder="Demora">
            </div>           

            
            
            <div class="form-group">
                <label for="clase">Clase</label>
                <select class="form-control" name="clase" id="clase">
                    <?php foreach ($clases as $clase) { ?>
                        <option value="<?php echo $clase ?>"><?php echo $clase ?></option>
                    <?php } ?>
                </select>
            </div>
       
<div class="form-group">
                <label for="detalle">Detalle</label>
                <input required type="text" class="form-control" name="detalle" id="detalle" placeholder="Detalle">
            </div>

            <div class="form-group">
                <label for="comision">Comision</label>
    <input value="<?php echo $producto->comision ?>" required type="text" class="form-control" name="comision" id="comision" placeholder="Comision" pattern="^\d{1,3}(.\d{3})*(\,\d{1,2})?$" title="Ingrese un valor válido para el .com">
            </div>


            <div class="form-group">
                <button class="btn btn-success">Guardar</button>
            </div>

        </form>
    </div>
</div>
<?php include_once "pie.php" ?>