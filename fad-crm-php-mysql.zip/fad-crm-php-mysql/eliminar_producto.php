<?php
/*

Creado por Jorge H. Valencia L (https://).

*/ 

?>

  <?php
include_once "funciones2.php";

$id = $_GET["id"] ?? null;

if (isset($_GET["confirm"])) {
    $ok = eliminarProducto($id);
    echo $ok ? "ok" : "error";
} else {
    echo '<script type="text/javascript">';
    
    echo 'if (confirm("¿Estás seguro de que quieres eliminar este producto?")) {';
    echo '  window.location.href="eliminar_producto.php?id=' . $id . '&confirm=true";';
    echo '  window.location.href="productos.php";';
   
    echo '} else {';
   
    echo '  window.location.href="productos.php";'; // Redirige de vuelta a productos.php si no se confirma
    echo '}';
    echo '</script>';
}
?>