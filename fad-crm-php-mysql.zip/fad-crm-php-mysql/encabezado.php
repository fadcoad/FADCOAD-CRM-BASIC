<?php
/*
Creado por Jorge Hernán Valencia (http://fad.com.co/fad.com).

*/ ?>
<!doctype html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="CRM">
    <title>CRM</title>
    <!-- Cargar el CSS de Boostrap-->
    <link href="./css/bootstrap.min.css" rel="stylesheet">

    <script src="./js/Chart.min.js"></script>

    <!-- Cargar estilos propios -->

    <link href="./css/estilo.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/@mdi/font@5.9.55/css/materialdesignicons.min.css" rel="stylesheet">

</head>

<body>

    <!-- Definición del menú -->

<div class="banner"> 

    <h3> CRM FADCOAD de <a class="navbar-brand" href="http://fad.22web.org">FAD</a></h3>
    
    
<button class="toggler" type="button" onclick="toggleMenu()">
     
    </button> 
   
    <h3>Vendedor</h3>
    
</div>

   
    <div class="collapse navbar-collapse" id="miNavbar">
        <ul class="navbar-nav mr-auto">

            <li class="nav-item">
                <a class="nav-link" href="clientes.php">Clientes</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="productos.php">Productos</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="ventas.php">Ventas</a>
            </li>          
            <li class="nav-item active">
                <a class="nav-link" href="http://whatsappfad.22web.org/">Ayuda y soporte</a>
            </li>
        </ul>

    
</div>



<main role="main" class="container-fluid toto">




  



<script>
    function toggleMenu() {
        var menu = document.getElementById("miNavbar");
        menu.classList.toggle("show");
    }
</script>

</body>

</html>