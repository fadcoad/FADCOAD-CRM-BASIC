<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "encabezado.php";
include_once "funciones.php";
$localidades = obtenerLocalidad();
$generos = obtenerGenero();
?>
<div class="row">
    <div class="col-12">
        <h1>Agregar cliente</h1>
        <form action="Guardar_cliente.php" method="post">

            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input required type="text" class="form-control" name="nombre" id="nombre" placeholder="Nombre">
            </div>
            
            <div class="form-group">
                <label for="identificacion">Identificación</label>
                <input required type="number" class="form-control" name="identificacion" id="identificacion" placeholder="Identificacion">
            </div>

            <div class="form-group">
                <label for="telefono">Teléfono</label>
                <input required type="number" class="form-control" name="telefono" id="telefono" placeholder="Telefono">
            </div>

            <div class="form-group">
                <label for="correo">Correo</label>
                <input required type="text" class="form-control" name="correo" id="correo" placeholder="Correo">
            </div>  
                      

            <div class="form-group">
                <label for="localidad">Localidad</label>
                <select class="form-control" name="localidad" id="localidad">
                    <?php foreach ($localidades as $localidad) { ?>
                        <option value="<?php echo $localidad ?>"><?php echo $localidad ?></option>
                    <?php } ?>
                </select>
            </div>
            

<div class="form-group">
                <label for="direccion">Dirección</label>
                <input required type="text" class="form-control" name="direccion" id="direccion" placeholder="Direccion">
            </div>

            
            <div class="form-group">
                <label for="genero">Genero</label>
                <select class="form-control" name="genero" id="genero">
                    <?php foreach ($generos as $genero) { ?>
                        <option value="<?php echo $genero ?>"><?php echo $genero ?></option>
                    <?php } ?>
                </select>
            </div>
            
            
            <div class="form-group">
                <label for="edad">Edad</label>
                <input required type="number" class="form-control" name="edad" id="edad" placeholder="Edad">
            </div>

            <div class="form-group">
                <button class="btn btn-success">Guardar</button>
            </div>

        </form>
    </div>
</div>
<?php include_once "pie.php" ?>