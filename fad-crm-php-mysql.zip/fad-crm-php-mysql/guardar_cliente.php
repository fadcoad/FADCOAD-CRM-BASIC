<?php
/* 

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "funciones.php";
$ok = agregarCliente($_POST["nombre"], $_POST["identificacion"], $_POST["telefono"], $_POST["correo"], $_POST["localidad"], $_POST["direccion"], $_POST["edad"]);
if (!$ok) {
    echo "Error registrando.";
} else {
    header("Location: clientes.php");
}
