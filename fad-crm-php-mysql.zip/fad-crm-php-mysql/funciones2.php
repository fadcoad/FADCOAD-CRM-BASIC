<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php

date_default_timezone_set("America/Bogota");

function obtenerClase()
{
    return [
        "Muebles",
        "Carros y carretas",
        "Avisos",
        "Puertas y ventanas",
        "Arte",
        "Software",
        
    ];
}



function obtenerBD()
{
    $password = "root";
    $user = "root";
    $dbName = "crm2";

$database = new PDO('mysql:host=localhost:3306;dbname=' . $dbName, $user, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
    
    $database->query("set names utf8;");
    $database->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);
    $database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $database->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    return $database;
}



function agregarProducto($nombre, $nip, $idfabricante, $precio, $existencias, $demora, $clase, $detalle, $comision)
{
    // Limpiar y formatear el precio
    $precio = str_replace(',', '.', str_replace('.', '', $precio));

    // Limpiar y formatear la comisión
    $comision = str_replace(',', '.', str_replace('.', '', $comision));

    $bd = obtenerBD();
    $fechaRegistro = date("Y-m-d");
    $sentencia = $bd->prepare("INSERT INTO productos(nombre, nip, idfabricante, precio, existencias, demora, clase, detalle, comision, fecha_registro) VALUES (?, ?, ?, ? ,? ,? ,? ,? ,? ,?)");
    return $sentencia->execute([$nombre, $nip, $idfabricante, $precio, $existencias, $demora, $clase, $detalle, $comision, $fechaRegistro]);
}



function obtenerProductos()
{
    $bd = obtenerBD();
    $sentencia = $bd->query("SELECT id, nombre, nip, idfabricante, precio, existencias, demora, clase, detalle, comision, fecha_registro FROM productos");
    
   // Recorrer los resultados y formatear precio y comision
    $productos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
    foreach ($productos as &$producto) {
        $producto['precio'] = number_format($producto['precio'], 2, ',', '.');
        $producto['comision'] = number_format($producto['comision'], 2, ',', '.');
    }
    return $productos;
    
}

function buscarProductos($nombre)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("SELECT id, nombre, nip, idfabricante, precio, existencias, demora, clase, detalle, comision, fecha_registro FROM productos WHERE nombre LIKE ?");
    
    // Ejecutar la consulta con el parámetro de búsqueda
    $sentencia->execute(["%$nombre%"]);
    
    // Recorrer los resultados y formatear precio y comision
    $productos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
    foreach ($productos as &$producto) {
        $producto['precio'] = number_format($producto['precio'], 2, ',', '.');
        $producto['comision'] = number_format($producto['comision'], 2, ',', '.');
    }
    
    return $productos;
}

function buscarProductosid($id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("SELECT id, nombre, nip, idfabricante, precio, existencias, demora, clase, detalle, comision, fecha_registro FROM productos WHERE id LIKE ?");
    
    // Ejecutar la consulta con el parámetro de búsqueda
    $sentencia->execute(["%$id%"]);
    
    // Recorrer los resultados y formatear precio y comision
    $productos = $sentencia->fetchAll(PDO::FETCH_ASSOC);
    foreach ($productos as &$producto) {
        $producto['precio'] = number_format($producto['precio'], 2, ',', '.');
        $producto['comision'] = number_format($producto['comision'], 2, ',', '.');
    }
    
    return $productos;
}

function obtenerProductoPorId($id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("SELECT id, nombre, nip, idfabricante, precio, existencias, demora, clase, detalle, comision, fecha_registro FROM productos WHERE id = ?");
    
    // Ejecutar la consulta con el parámetro de búsqueda
    $sentencia->execute([$id]);
    
    // Recorrer los resultados y formatear precio y comision
    $producto = $sentencia->fetch(PDO::FETCH_ASSOC);
    if ($producto) {
        $producto['precio'] = number_format($producto['precio'], 2, ',', '.');
        $producto['comision'] = number_format($producto['comision'], 2, ',', '.');
    }
    
    return $produco;
}


function eliminarProducto($id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("DELETE FROM productos WHERE id = ?");
    return $sentencia->execute([$id]);
}

function actualizarProducto($nombre, $nip, $idfabricante, $precio,  $existencias, $demora, $clase, $detalle, $comision, $id)
 {
    
    $bd = obtenerBD();
    $fechaRegistro = date("Y-m-d");
    $sentencia = $bd->prepare("UPDATE productos SET nombre = ?, nip = ?, idfabricante = ?, precio = ?, existencias = ?, demora = ?, clase = ?, detalle = ?, comision = ?, fecha_registro = ? WHERE id = ?");
    return $sentencia->execute([$nombre, $nip, $idfabricante, $precio, $existencias, $demora, $clase, $detalle, $comision, $fechaRegistro, $id]);

function agregarVenta($idProducto, $monto, $fecha)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("INSERT INTO ventas_clientes(id_cliente, monto, fecha) VALUES (?, ?, ?)");
    return $sentencia->execute([$idCliente, $monto, $fecha]);
}

}