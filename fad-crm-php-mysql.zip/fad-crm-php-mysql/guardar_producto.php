<?php
/* 

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "funciones2.php";
$ok = agregarProducto($_POST["nombre"], $_POST["nip"], $_POST["idfabricante"], $_POST["precio"], $_POST["existencias"], $_POST["demora"], $_POST["clase"], $_POST["detalle"], $_POST["comision"]);
if (!$ok) {
    echo "Error registrando.";
} else {
    header("Location: productos.php");
}
