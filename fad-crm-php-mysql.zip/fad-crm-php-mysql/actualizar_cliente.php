<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "funciones.php";
$ok = actualizarCliente($_POST["nombre"], $_POST["identificacion"], $_POST["telefono"], $_POST["correo"], $_POST["localidad"], $_POST["direccion"], $_POST["genero"], $_POST["edad"], $_POST["id"]);
if (!$ok) {
    echo "Error actualizando.";
} else {
    header("Location: clientes.php");
}
