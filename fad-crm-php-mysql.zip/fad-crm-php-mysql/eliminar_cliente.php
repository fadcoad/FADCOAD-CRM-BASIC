<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "funciones.php";
$ok = eliminarCliente($_GET["id"]);
if (!$ok) {
    echo "Error eliminando";
} else {
    header("Location: Clientes.php");
}
