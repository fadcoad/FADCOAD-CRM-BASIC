<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php

date_default_timezone_set("America/Bogota");

function obtenerLocalidad()
{
    return [
        "1. Usaquén",
        "2. Chapinero",
        "3. Santa Fe",
        "4. San Cristóbal",
        "5. Usme",
        "6. Tunjuelito",
        "7. Bosa",
        "8. Kennedy",
        "9. Fontibón",
        "10. Engativá",
        "11. Suba",
        "12. Barrios Unidos",
        "13. Teusaquillo",
        "14. Los Mártires",
        "15. Antonio Nariño",
        "16. Puente Aranda",
        "17. Candelaria",
        "18. Rafael Uribe Uribe",
        "19. Ciudad Bolívar",
        "20. Sumapaz",
    ];
}

function obtenerGenero()
{
    return[
          "",
          "M",
          "F",
          ];
}


function obtenerBD()
{
    $password = "root";
    $user = "root";
    $dbName = "crm2";

$database = new PDO('mysql:host=localhost:3306;dbname=' . $dbName, $user, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));


    
    $database->query("set names utf8;");
    $database->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);
    $database->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $database->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_OBJ);
    return $database;
}

function agregarCliente($nombre, $identificacion, $telefono, $correo, $localidad, $direccion, $geneeo, $edad)
{
    $bd = obtenerBD();
    $fechaRegistro = date("Y-m-d");
    $sentencia = $bd->prepare("INSERT INTO clientes(nombre, identificacion, telefono, correo, departamento, direccion, genero, edad, fecha_registro) VALUES (?, ?, ?, ? ,? ,? ,? ,? ,?)");
    return $sentencia->execute([$nombre, $identificacion, $telefono, $correo, $localidad, $direccion, $genero, $edad, $fechaRegistro]);
}


function obtenerClientes()
{
    $bd = obtenerBD();
    $sentencia = $bd->query("SELECT id, nombre, identificacion, telefono, correo, localidad, direccion, genero, edad, fecha_registro FROM clientes");
    return $sentencia->fetchAll();
}


function buscarClientes($nombre)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("SELECT id, nombre, identificacion, telefono, correo, localidad, direccion, genero, edad, fecha_registro FROM clientes WHERE nombre LIKE ?");
    $sentencia->execute(["%$nombre%"]);
    return $sentencia->fetchAll();
} 


function eliminarCliente($id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("DELETE FROM clientes WHERE id = ?");
    return $sentencia->execute([$id]);
}

function obtenerClientePorId($id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("SELECT id, nombre, identificacion, telefono, correo, localidad, direccion, genero, edad, fecha_registro FROM clientes WHERE id = ?");
    $sentencia->execute([$id]);
    return $sentencia->fetchObject();
}

function actualizarCliente($nombre, $identificacion, $telefono, $correo,  $localidad, $direccion, $genero, $edad, $id)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("UPDATE clientes SET nombre = ?, identificacion = ?, telefono = ?, correo = ?, localidad = ?, direccion = ?, genero = ?, edad = ? WHERE id = ?");
    return $sentencia->execute([$nombre, $identificacion, $telefono, $correo, $localidad, $direccion, $genero, $edad, $id]);
}

function agregarVenta($idCliente, $monto, $fecha)
{
    $bd = obtenerBD();
    $sentencia = $bd->prepare("INSERT INTO ventas_clientes(id_cliente, monto, fecha) VALUES (?, ?, ?)");
    return $sentencia->execute([$idCliente, $monto, $fecha]);
}

