<?php
/*

Creado por Jorge H. Valencia L.(http://fad.com.co/fad.com.co).

*/ ?>
<?php
include_once "encabezado.php";
include_once "funciones2.php";
if (!isset($_GET["busqueda"]) || empty($_GET["busqueda"])) {
    $productos = obtenerProductos();
} else {
    $productos = buscarProductosid($_GET["busqueda"]);
}

?>
<div class="row">
    <div class="col-12">
        <h1>Productos</h1>
        
        <a href="formulario_agregar_producto.php" class="btn btn-success mb-2">Agregar</a>
        
        <form action="productos.php">
        
            <div class="form-row align-items-center">
                             
                <div class="col-6 my-1">                
                    <input value="<?php echo isset($_GET["busqueda"]) && !empty($_GET["busqueda"]) ?  $_GET["busqueda"] : "" ?>" name="busqueda" class="form-control" type="text" placeholder="Buscar producto por nombre">
                </div>              
                
                <div class="col-auto my-1">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
                        
        </form>
                
        <table class="table">
            <thead>

                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>NIP</th>
                    <th>ID Fabricante</th>
                    <th>Precio</th>
                    <th>Existencias</th>
                    <th>Demora</th>
                    <th>Clase</th>
                    <th>Detalle</th>
                    <th>.com</th>
                    <th>Fecha actualización</th>
                    <th>Editar</th>
                    <th>Eliminar</th>
                </tr>
            </thead>
            <tbody>
              <?php foreach ($productos as $producto) { ?>
                <tr>
        <td><?php echo $producto['id'] ?></td>
        <td><?php echo $producto['nombre'] ?></td>
        <td><?php echo $producto['nip'] ?></td>
        <td><?php echo $producto['idfabricante'] ?></td>
        <td><?php echo $producto['precio'] ?></td>
        <td><?php echo $producto['existencias'] ?></td>
        <td><?php echo $producto['demora'] ?></td>
        <td><?php echo $producto['clase'] ?></td>
        <td><?php echo $producto['detalle'] ?></td>
        <td><?php echo $producto['comision'] ?></td>
        <td><?php echo $producto['fecha_registro'] ?></td>                                                        
                        
                        <td>
                            <a class="btn btn-warning" href="formulario_editar_producto.php?id=<?php echo $producto['id']; ?>">Editar</a>
                        </td>
                        <td>
                            <a class="btn btn-danger" href="eliminar_producto.php?id=<?php echo $producto['id'];
                           
                            ?>">Eliminar</a>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php include_once "pie.php" ?>
